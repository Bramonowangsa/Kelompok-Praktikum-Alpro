#include <iostream>
#include <fstream>
#include "../library/input.h"

int main(){
  input input;
  input.cetak();
  input.toFile();
  return 0;
}