using namespace std;

class input {
  public :
    void cetak(){
      cout << "Aplikasi penjualan ayam\n";
      cout << "Menu yang tersedia : \n";
      cout << "1) Ayam Goreng Rp. 17.000\n";
      cout << "2) Ayam Bakar Rp. 25.000\n";
      cout << "3) Ayam Geprek Rp.21.000\n";
      cout << "4) Udang Goreng Rp. 19.000\n";
      cout << "5) Cumi Goreng Rp. 25.000\n";
      cout << "Pesan ayam goreng -> "; cin >>bnyk_aymGr;
      cout << "Pesan ayam bakar - > "; cin >>bnyk_aymBk;
      cout << "Pesan ayam geprek- > "; cin >>bnyk_aymGp;
      cout << "Pesan udang goreng ->"; cin>>bnyk_udgGr;
      cout << "Pesan cumi goreng ->"; cin>>bnyk_cmiGr;
    }
  void toFile(){
    tulis_data.open("api_data.txt");
    tulis_data <<bnyk_aymGr<<endl;
    tulis_data <<bnyk_aymBk<<endl;
    tulis_data <<bnyk_aymGp<<endl;
    tulis_data <<bnyk_udgGr<<endl;
    tulis_data <<bnyk_cmiGr<<endl;
    tulis_data.close();
  }
  private:
  ofstream tulis_data;
  int bnyk_aymGr, bnyk_aymBk, bnyk_aymGp, bnyk_udgGr, bnyk_cmiGr;
};