using namespace std;


class Proses{
  public:
    void cetak(){
      cout << "You do Processing \n";
    }
    void getData(){
      ambil_data.open("api_data.txt");
      bool ayam_goreng = true;
      while(!ambil_data.eof()){
        if(ayam_goreng){
          ambil_data >> bnyk_aymGr;
        }
          if(ayam_bakar) {
            ambil_data >> bnyk_aymBk;
          }
          if(ayam_geprek) {
              ambil_data >>bnyk_aymGp;
            }
          if(udang_goreng){
                ambil_data >>bnyk_udgGr;
                udang_goreng = false;
              }
                
        else{
          ambil_data >> bnyk_cmiGr;
        }
      }
      ambil_data.close();
    }

    void tofile(){
      int total = (hrg_aymGp * bnyk_aymGp)+(hrg_aymBk * bnyk_aymBk)+(hrg_aymGp * bnyk_aymGp)+(hrg_udgGr * bnyk_udgGr)+(hrg_cmiGr * bnyk_cmiGr);
      float batas = 45000;
      float t2 = float(total);
      float diskon = t2 * 0.1;

      if(total >= batas)
        t2 = t2 - diskon;
      tulis_data.open("api_data.txt");
      tulis_data << total << endl;
      tulis_data << diskon << endl;
      tulis_data << t2 << endl;
      tulis_data << bnyk_aymGr <<endl;
      tulis_data << bnyk_aymBk <<endl;
      tulis_data << bnyk_aymGp <<endl;
      tulis_data << bnyk_udgGr <<endl;
      tulis_data << bnyk_cmiGr;
      tulis_data.close();
    }

  private :
    ifstream ambil_data;
    ofstream tulis_data;
    int ayam_bakar;
    int ayam_geprek;
    int udang_goreng;
    int cumi_goreng;

    int bnyk_aymGr;
    int bnyk_aymBk;
    int bnyk_aymGp;
    int bnyk_udgGr;
    int bnyk_cmiGr;
    
    int hrg_aymGr = 17000;
    int hrg_aymBk = 25000;
    int hrg_aymGp = 21000;
    int hrg_udgGr = 19000;
    int hrg_cmiGr = 25000;

};