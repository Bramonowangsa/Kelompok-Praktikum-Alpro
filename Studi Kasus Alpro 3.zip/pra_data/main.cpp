#include<iostream>
#include<fstream>
#include"../library/input.h"
#include"../library/proses.h"
#include"../library/output.h"

int main(){
	input input;
	input.cetak();
  input.toFile();
	
	Proses Proses;
  Proses.getData();
  Proses.tofile();
  	
  Output output;
  output.getData();
  output.cetak();
  	
  	return 0;
}